package com.example.lesliexong.opencollector.collectorservice;

public class XWiFi extends XBasic {
    XWiFi(String mac, int rssi) {
        super(mac, rssi);
    }
}
